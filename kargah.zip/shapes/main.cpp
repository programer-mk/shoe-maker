#include <iostream>
#include "Point.h"
#include "Shape.h"
#include "Rectangle.h"

using namespace std;


void test(int n){

    cout << "hihihihi" << endl;
    cout << n << endl;
    n++;
    if(n >3)
        return;
    test(n);

    exit(0);

    cout << "lilili "<< endl;
    cout << (n-1) << endl;

    cout << "------------" << endl;


}


int main()
{
    /*Shape sh1;
    Rectangle rec1;

    cout << "shape class: " << endl;
    sh1.Print_Point();
    sh1.Print_Shap();

    cout << endl;

     cout << "Rectangle class: " << endl;

    rec1.Print_Point();
    rec1.Print_Shap();


    cout << "---------------------" << endl;


    cout << "shape class: " << endl;
    Shape *sh_p;
    sh_p = &rec1;



    sh_p->Print_Point(); // not virtual
    sh_p->Print_Shap(); // virtual*/

    test(0);


    return 0;
}
