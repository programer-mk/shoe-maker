#ifndef SHAPE_H
#define SHAPE_H

#include <iostream>
#include <string>
#include "Point.h"

using namespace std;

class Shape
{
    public:
        Shape();
        Shape(int);
        virtual ~Shape();
        void setSize(int);
        int getSize();

        void Print_Point();
        virtual void Print_Shap();


    protected:
        int size;
        Point *angles;
        string name;
    private:

};

#endif // SHAPE_H
