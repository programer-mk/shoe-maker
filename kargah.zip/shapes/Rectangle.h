#ifndef RECTANGLE_H
#define RECTANGLE_H
#include "Shape.h"

#include <iostream>
#include <string>

using namespace std;




class Rectangle: public Shape
{
    public:
        Rectangle();
        virtual ~Rectangle();
        int getSize();

        void Print_Point();
        void Print_Shap();

    protected:
        //not private
        // square Class needs them
        int width;
        int length;

    private:
};

#endif // RECTANGLE_H
