#include "Cylindrical.h"

Cylindrical::Cylindrical()
{
    //ctor
}

Cylindrical::~Cylindrical()
{
    //dtor
}
