#include "Triagle.h"

Triagle::Triagle()
{
    //ctor
}

Triagle::~Triagle()
{
    //dtor
}
