#include "Point.h"

Point::Point()
{
    x = 5;
    y = 7;
}

Point::Point(int x, int y)
{
    this->x = x;
    this->y = y;
}


void Point::setPoint(int x, int y)
{
    this->x = x;
    this->y = y;
}


Point::Point(const Point *p)
{
    *this = p;
}

Point::~Point()
{
    //dtor
}

void Point::print_Point(string name){
    cout << "point "<< name  <<" = (" << x << ", " << this->y << ") " << endl;
}


void Point::someFinction(){
    int x = 9999999;

    this->x = 10;

    cout << x << endl;
    cout << this->x << endl;
}
