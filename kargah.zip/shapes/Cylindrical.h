#ifndef CYLINDRICAL_H
#define CYLINDRICAL_H


class Cylindrical
{
    public:
        Cylindrical();
        virtual ~Cylindrical();

    protected:

    private:
};

#endif // CYLINDRICAL_H
