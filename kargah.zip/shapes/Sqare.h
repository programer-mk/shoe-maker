#ifndef SQARE_H
#define SQARE_H


class Sqare
{
    public:
        Sqare();
        virtual ~Sqare();

    protected:

    private:
};

#endif // SQARE_H
