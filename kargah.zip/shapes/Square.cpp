#include "Square.h"

Square::Square()
{
    //ctor
}

Square::~Square()
{
    //dtor
}
