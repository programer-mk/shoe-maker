#ifndef TRIAGLE_H
#define TRIAGLE_H


class Triagle
{
    public:
        Triagle();
        virtual ~Triagle();

    protected:

    private:
};

#endif // TRIAGLE_H
