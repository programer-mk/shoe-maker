#ifndef POINT_H
#define POINT_H

#include <iostream>
#include <string>
using namespace std;


class Point
{
    public:
        //TODO: define 3 type of constructor
        Point(); //default constructor
        Point(int, int); // parameterize
        Point(const Point *); // copy
        virtual ~Point();

        //set :
        // input => self
        // output => void

        //get :
        // input => void
        // output => self


        int Getx() { return x; }
        void Setx(int val) { x = val; }


        int Gety() { return y; }
        void Sety(int val) { y = val; }


        void setPoint(int, int);
        void someFinction();
        void print_Point(string);

    private:
        int x;
        int y;

};

#endif // POINT_H
