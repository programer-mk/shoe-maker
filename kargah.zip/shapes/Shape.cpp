#include "Shape.h"

Shape::Shape()
{
    size = 1;
    angles = new Point[1];
}

Shape::Shape(int size){
    this->size = size;
    angles = new Point[size];
}

Shape::~Shape()
{
    //dtor
}


int Shape::getSize(){
    return size;
}


void Shape::Print_Point(){
    for(int i = 0; i < size; i++)
        angles[i].print_Point("P(" + to_string(i) + ")");
}


//virtual
void Shape::Print_Shap(){
    cout << "ther is no shape" << endl;
}
