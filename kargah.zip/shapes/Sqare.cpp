#include "Sqare.h"

Sqare::Sqare()
{
    //ctor
}

Sqare::~Sqare()
{
    //dtor
}
