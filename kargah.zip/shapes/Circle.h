#ifndef CIRCLE_H
#define CIRCLE_H


class Circle
{
    public:
        Circle();
        virtual ~Circle();

    protected:

    private:
};

#endif // CIRCLE_H
