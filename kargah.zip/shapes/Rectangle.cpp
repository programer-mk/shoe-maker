#include "Rectangle.h"

Rectangle::Rectangle()
{
    Shape::size = 4;
    angles = new Point[size];

    width = 1;
    length = 2;

    name = "rectangle";

    angles[0].setPoint(0,0);
    angles[1].setPoint(0, length);
    angles[2].setPoint(width,0);
    angles[3].setPoint(width, length);
    //ctor
}

Rectangle::~Rectangle()
{
    //dtor
}


void Rectangle::Print_Point(){
    cout << "man baadan Point haro print mikonam!" << endl;

}

// virtual function in shap
void Rectangle::Print_Shap(){
    cout << "shape is : " << name << endl;

}

