#include "Circle.h"

Circle::Circle()
{
    //ctor
}

Circle::~Circle()
{
    //dtor
}
